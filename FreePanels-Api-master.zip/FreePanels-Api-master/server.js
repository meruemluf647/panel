const express = require('express');
const axios = require('axios');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const PTERO_URL = process.env.PTERO_URL;
const API_KEY = process.env.PTERO_API_KEY;

if (!PTERO_URL || !API_KEY) {
    console.error("[ERREUR CRITIQUE] PTERO_URL ou PTERO_API_KEY manquant dans le .env");
}

let cleanUrl = PTERO_URL ? PTERO_URL.trim().replace(/\/+$/, "") : "";
if (cleanUrl.includes("/api/application")) cleanUrl = cleanUrl.replace("/api/application", "");

const ptero = axios.create({
    baseURL: `${cleanUrl}/api/application`,
    headers: {
        'Authorization': `Bearer ${API_KEY}`,
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    }
});

const NEST_EGG_MAPPING = {
    minecraft: { nest: 1, egg: 1 },
    nodejs: { nest: 6, egg: 15 },
    rust: { nest: 4, egg: 14 },
    website: { nest: 6, egg: 15 },
};

// Fonction pour récupérer dynamiquement les variables d'un Egg
async function getEggEnvironment(nestId, eggId, userVersion, type) {
    try {
        const response = await ptero.get(`/nests/${nestId}/eggs/${eggId}?include=variables`);
        const variables = response.data.attributes.relationships.variables.data;
        
        const env = {};
        variables.forEach(v => {
            const key = v.attributes.env_variable;
            const defaultValue = v.attributes.default_value;
            env[key] = defaultValue;

            if (userVersion && userVersion !== 'latest') {
                const upperKey = key.toUpperCase();
                if (upperKey.includes('VERSION') || upperKey.includes(type.toUpperCase())) {
                    env[key] = userVersion;
                }
            }

            if (type === 'nodejs' && key === 'COMMAND_RUN' && userVersion) {
                env[key] = `node ${userVersion}`;
            }
        });

        return env;
    } catch (err) {
        console.error(`[EGG-LOADER] Erreur lors du chargement des variables Nest:${nestId} Egg:${eggId}`, err.message);
        return {};
    }
}

// ====================== ROUTES ======================

app.get('/health', async (req, res) => {
    try {
        const response = await ptero.get('/nodes');
        res.json({ status: "OK", nodes: response.data.data.length });
    } catch (err) {
        res.status(500).json({ status: "ERROR", detail: err.response?.data || err.message });
    }
});

app.get('/user/:username', async (req, res) => {
    try {
        const response = await ptero.get(`/users?filter[username]=${req.params.username}`);
        if (response.data.data.length > 0) {
            const user = response.data.data[0].attributes;
            return res.json({ exists: true, id: user.id, email: user.email });
        }
        res.json({ exists: false });
    } catch (err) {
        res.status(500).json({ message: "Erreur Panel" });
    }
});

app.post('/create-user', async (req, res) => {
    const { username, email, password } = req.body;
    try {
        const response = await ptero.post('/users', {
            username, email, password,
            first_name: username, last_name: 'FreeUser'
        });
        res.json({ id: response.data.attributes.id, message: "Account created" });
    } catch (err) {
        const detail = err.response?.data?.errors?.[0]?.detail || "Error creating user";
        res.status(400).json({ message: detail });
    }
});

app.post('/create-server', async (req, res) => {
    const { userId, name, type, version } = req.body;
    const ids = NEST_EGG_MAPPING[type] || NEST_EGG_MAPPING.minecraft;

    try {
        console.log(`[DEPLOY] Loading variables for ${type}...`);
        const dynamicEnv = await getEggEnvironment(ids.nest, ids.egg, version, type);

        let locationId = 2;
        try {
            const locRes = await ptero.get('/locations');
            if (locRes.data.data.length > 0) locationId = locRes.data.data[0].attributes.id;
        } catch (e) {}

        const eggDetail = await ptero.get(`/nests/${ids.nest}/eggs/${ids.egg}`);
        const dockerImage = eggDetail.data.attributes.docker_image;
        const startupCommand = eggDetail.data.attributes.startup;

        const now = Date.now();
        const expiry = now + 30 * 24 * 60 * 60 * 1000; // 4 jours

        const serverData = {
            name,
            user: parseInt(userId),
            egg: ids.egg,
            nest: ids.nest,
            docker_image: dockerImage,
            startup: startupCommand,
            environment: dynamicEnv,
            limits: { memory: 0, swap: 0, disk: 0, io: 500, cpu: 0 },
            feature_limits: { databases: 0, allocations: 0, backups: 0 },
            deploy: { locations: [locationId], dedicated_ip: false, port_range: [] },
            start_on_completion: true,
            created_at: now,
            expiry_date: expiry
        };

        const response = await ptero.post('/servers', serverData);
        res.json({ id: response.data.attributes.id, createdAt: now, expiryDate: expiry });
    } catch (err) {
        console.error("Détails Erreur Ptero:", JSON.stringify(err.response?.data));
        const errorDetail = err.response?.data?.errors?.[0]?.detail || "Erreur de configuration du panel.";
        res.status(err.response?.status || 500).json({ message: errorDetail });
    }
});

app.delete('/delete-server/:id', async (req, res) => {
    try {
        await ptero.delete(`/servers/${req.params.id}`);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ message: "Erreur suppression" });
    }
});

// ====================== SUSPENSION / RENOUVELLEMENT ======================

app.post('/resume-server/:id', async (req, res) => {
    try {
        await ptero.post(`/servers/${req.params.id}/resume`);
        res.json({ success: true });
    } catch(err) {
        res.status(500).json({ message: "Erreur réactivation" });
    }
});

// ====================== SERVEUR ======================

const PORT = process.env.PORT || 3003;

app.listen(PORT, () => {
  console.log(`[FreePanels-API] Ready on port ${PORT}`);
});
